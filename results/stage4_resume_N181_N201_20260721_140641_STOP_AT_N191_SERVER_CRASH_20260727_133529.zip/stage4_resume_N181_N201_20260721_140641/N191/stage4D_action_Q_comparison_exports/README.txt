# Stage 4D action-derived Q comparison

Memory mode: streaming sequential tensor scoring.

DIM = 4
N = 191
lambda_fit = 0.016759636831295006
beta_fit = -1.0419365581915676
beta_action = -1.0

Relative tensor difference action vs fit = 0.032589 %
Fitted normalized residual = 0.005802102531824074
Action normalized residual = 0.005809228992486495
Action residual / fitted residual = 1.0012282548650826
Residual penalty percent = 0.122825 %
