# Stage 4D action-derived Q comparison

Memory mode: streaming sequential tensor scoring.

DIM = 4
N = 181
lambda_fit = 0.016745814567971955
beta_fit = -1.0418121383514787
beta_action = -1.0

Relative tensor difference action vs fit = 0.032552 %
Fitted normalized residual = 0.005818144864296481
Action normalized residual = 0.005824962288971568
Action residual / fitted residual = 1.0011717523083559
Residual penalty percent = 0.117175 %
