# Stage 4D action-derived Q comparison

This package compares:

1. Best fitted HTR tensor:
   Q_fit = H - lambda_fit g S + beta_fit S G

2. Action-predicted tensor:
   Q_action = H - lambda_fit g S - S G

3. Difference:
   Q_action - Q_fit

Parameters:
DIM = 4
N = 81
lambda_fit = 0.016227418581089042
beta_fit = -1.0365130131338942
beta_action = -1.0

Key results:
Relative tensor difference action vs fit = 0.030533 %
Fitted normalized residual = 0.010241875755526996
Action normalized residual = 0.01024212618058182
Action residual / fitted residual = 1.0000244510928271
Residual penalty percent = 0.002445 %

Interpretation:
If the action-predicted beta=-1 tensor has nearly the same residual and tensor shape as
the fitted HTR tensor, then the numerical Stage 4C result is supported by a minimal
effective action rather than being only a numerical fit.
