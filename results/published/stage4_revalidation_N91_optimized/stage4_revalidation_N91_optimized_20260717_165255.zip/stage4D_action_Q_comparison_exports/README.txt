# Stage 4D action-derived Q comparison

Memory mode: streaming sequential tensor scoring.

DIM = 4
N = 91
lambda_fit = 0.01635688346979677
beta_fit = -1.0379699273529728
beta_action = -1.0

Relative tensor difference action vs fit = 0.031171 %
Fitted normalized residual = 0.008660663765603933
Action normalized residual = 0.008661503553999068
Action residual / fitted residual = 1.0000969658236207
Residual penalty percent = 0.009697 %
