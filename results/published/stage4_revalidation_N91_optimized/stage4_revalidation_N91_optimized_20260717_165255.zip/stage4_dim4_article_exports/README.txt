# Stage 4 DIM=4 article export package

Generated for updating the HTML technical article.

DIM = 4
N = 91

Main CSV files:
- run_metadata.csv
- stage4A_dim4_bianchi_validation.csv
- stage4B_dim4_hessian_Q_proxy.csv
- stage4C_dim4_fit_parameters.csv
- stage4C_dim4_candidate_ranking.csv

Main PNG files:
- stage4A_dim4_rho_from_einstein_tensor.png
- stage4A_dim4_known_rho_A.png
- stage4A_dim4_rho_error_map.png
- stage4A_dim4_bianchi_residual_map.png
- stage4B_dim4_scalar_seed_S.png
- stage4B_dim4_Q00_hessian_candidate.png
- stage4B_dim4_Q_residual_magnitude.png
- stage4B_dim4_Q00_vs_rhoA_cut.png
- stage4C_dim4_candidate_ranking.png
- stage4C_dim4_residual_cancellation_components.png
- stage4C_dim4_best_Q00.png
- stage4C_dim4_best_residual_map.png
- stage4C_dim4_best_Q00_vs_rhoA_cut.png

Best direct candidate:
HTR lambda_fit=0.0163569, beta_fit=-1.03797

Stage 4A:
relative_Bianchi_residual = 0.002819880281060446
rho_relative_peak_error = 0.022740302310159808

Stage 4B:
Hessian normalized_Q_conservation_residual = 0.01240857338767482

Stage 4C:
lambda_fit = 0.01635688346979677
beta_fit = -1.0379699273529728
analytic HTR improvement over H = 0.43457705785139966
