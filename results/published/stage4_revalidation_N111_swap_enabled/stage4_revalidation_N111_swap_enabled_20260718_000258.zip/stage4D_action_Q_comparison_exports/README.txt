# Stage 4D action-derived Q comparison

Memory mode: streaming sequential tensor scoring.

DIM = 4
N = 111
lambda_fit = 0.016524255632360423
beta_fit = -1.0397122617163324
beta_action = -1.0

Relative tensor difference action vs fit = 0.031853 %
Fitted normalized residual = 0.006974356346946944
Action normalized residual = 0.006976902350055349
Action residual / fitted residual = 1.0003650520538028
Residual penalty percent = 0.036505 %
