# Stage 4D action-derived Q comparison

Memory mode: streaming sequential tensor scoring.

DIM = 4
N = 61
lambda_fit = 0.015789560483007618
beta_fit = -1.0306645653701305
beta_action = -1.0

Relative tensor difference action vs fit = 0.027417 %
Fitted normalized residual = 0.01661441080787198
Action normalized residual = 0.0166147873767621
Action residual / fitted residual = 1.0000226651967665
Residual penalty percent = 0.002267 %
