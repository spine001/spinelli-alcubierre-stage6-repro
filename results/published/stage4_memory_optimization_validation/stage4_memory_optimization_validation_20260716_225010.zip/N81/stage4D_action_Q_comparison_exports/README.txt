# Stage 4D action-derived Q comparison

Memory mode: streaming sequential tensor scoring.

DIM = 4
N = 81
lambda_fit = 0.016227418581089042
beta_fit = -1.0365130131338942
beta_action = -1.0

Relative tensor difference action vs fit = 0.030533 %
Fitted normalized residual = 0.010241875755526996
Action normalized residual = 0.01024212618058182
Action residual / fitted residual = 1.0000244510928271
Residual penalty percent = 0.002445 %
