# Stage 4D action-derived Q comparison

Memory mode: streaming sequential tensor scoring.

DIM = 4
N = 101
lambda_fit = 0.016452255371338965
beta_fit = -1.0389808711441213
beta_action = -1.0

Relative tensor difference action vs fit = 0.031578 %
Fitted normalized residual = 0.007637756312486901
Action normalized residual = 0.007639409221561977
Action residual / fitted residual = 1.0002164129107358
Residual penalty percent = 0.021641 %
